Feature: User Login Functionality
Scenario: Verify user can log in with correct credentials
Given User is on the application login page
When User enters a valid username and password
And User clicks on the Login button
Then User should be directed to the homepage




