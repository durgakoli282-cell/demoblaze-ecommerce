package RunerClass;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinitions {
	@Given("User is on the application login page")
	public void user_is_on_the_application_login_page() {
		System.out.println("Hello @Given");
		}
	@When("User enters a valid username and password")
	public void user_enters_a_valid_username_and_password() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}
	@When("User clicks on the Login button")
	public void user_clicks_on_the_login_button() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}
	@Then("User should be directed to the homepage")
	public void user_should_be_directed_to_the_homepage() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}



}
