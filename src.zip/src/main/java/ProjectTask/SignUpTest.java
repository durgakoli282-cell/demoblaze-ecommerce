package ProjectTask;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import cucumber.api.cli.Main;

public class SignUpTest extends BaseTest {
	
	String reportPath =System.getProperty("user.dir") +"/Reports/ExtentReport"+timeStamp+".html";
	ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
	ExtentReports extent = new ExtentReports();
	Alert al;
	
	public void SingUp() {
		extent.attachReporter(spark);
		spark.config().setReportName("Demoblaze Automation Project");
		spark.config().setDocumentTitle("Demoblaze Sign Up Automation.");
		extent.setSystemInfo("Demoblaze E-Commerce Website Automation.", "Demoblaze Automation Framework.");
		ExtentTest test = extent.createTest("Demoblaze_SignUp", 
				"Validating the title of Demoblaze homepage without TestNG");
		
		String bName="Chrome";
		LaunchBrowser(bName);
		try
		{
	    test.log(Status.INFO,bName +"Browser Launched successfully." );
	    driver.manage().window().maximize();
	    driver.get("https://www.demoblaze.com/");
	    test.log(Status.PASS, "Navigated to Demoblaze website successfully.");
	    test.log(Status.INFO, driver.getCurrentUrl());
	    Thread.sleep(1000);
	    
	    driver.findElement(By.id("signin2")).click();
		test.log(Status.PASS, "Login button clicked successfully.");
		Thread.sleep(1800);
		
		String path1 =CaptureScreenshot("Step3_SignUpPage");
		test.log(Status.INFO, "Screen captured for Demoblaze login page-Step1.");
		test.addVideoFromPath(path1);
		
		driver.findElement(By.id("sign-username")).sendKeys("Rekha_3214");
		test.log(Status.PASS, " Valid UserId entered successfully. ");
		Thread.sleep(1800);
		driver.findElement(By.id("sign-password")).sendKeys("Rekha12");
		test.log(Status.PASS, "Valid Password entered successfully. ");
		Thread.sleep(2000);

		String path2 =CaptureScreenshot("Step2_BeforeSignUpPage");
		test.log(Status.INFO, "Screen captured for Demoblaze LoginPage before Sign up-step 2.");
		test.addScreenCaptureFromPath(path2);
		Thread.sleep(1500);

		driver.findElement(By.xpath("//button[starts-with(@onclick,\"register()\")]")).click();
		test.log(Status.PASS, "Sign up button clicked Successfully.");
		Thread.sleep(2100);

		al=driver.switchTo().alert();
		test.log(Status.INFO,"Sign up with valid date-Alert: "+al.getText());


		}
		catch( Exception e) {
			test.fail("Test encountered an exception: " + e.getMessage());
		}
		finally {

			if (driver != null) {
				driver.quit();
				test.log(Status.INFO, "Browser closed successfully.");
			}
			extent.flush();
			System.out.println("Execution complete. \nReport generated at: " + reportPath);
		
		
	}
		

	}
	public static void main(String[] args) {
		SignUpTest o=new SignUpTest();
		o.SingUp();
	}

}