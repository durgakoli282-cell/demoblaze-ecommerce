package ProjectTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class BaseTest {
	public WebDriver driver;

	public String timeStamp = new 	SimpleDateFormat
			("yyyyMMdd_HHmmss").format(new Date());
	public void LaunchBrowser(String sBrowser) {
		if(sBrowser.equalsIgnoreCase("Chrome")){
			driver=new ChromeDriver();
		}
		else if (sBrowser.equalsIgnoreCase("Edge")){
			driver=new EdgeDriver();
		}
		else {
			System.out.println("Invalid Value");
		}
	}

	public String CaptureScreenshot(String Screenshort) throws IOException, InterruptedException {
		Thread.sleep(1000);
		String timeStamp = new 	SimpleDateFormat
				("yyyyddMM_HHmmss").format(new Date());

		File Source =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String path ="G:\\Automation\\Screenshort\\DemoblazeScreenCap_"+Screenshort+"_"+timeStamp+".png";
		File dest=new File(path);
		FileHandler.copy(Source, dest);
		System.out.println("Screenshort Saved:"+path);

		return path;
	}

}







