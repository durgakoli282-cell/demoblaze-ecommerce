package ProjectTask;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver.SystemProperty;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class DemoblazeSOpen extends BaseTest {
	String reportPath = System.getProperty("user.dir") +"/Reports/ExtentReport"+timeStamp+".html";
	ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
	ExtentReports extent = new ExtentReports();
	Alert al;


	public void DemoblazeLogin() {
		extent.attachReporter(spark);
		
		spark.config().setReportName("Demoblaze Automation Project.");
        spark.config().setDocumentTitle("Demoblaze E-Commerce Website Automation.");
        extent.setSystemInfo("Demoblaze E-Commerce Website Automation.", "Demoblaze Automation Framework.");
		ExtentTest test = extent.createTest("Demoblaze_ValidLogin", 
				"Validating the title of Demoblaze homepage without TestNG");
		String bName="Chrome";
		LaunchBrowser(bName);
		try {
			test.log(Status.INFO, bName+" Browser Launched successfully.");
			driver.manage().window().maximize();
			driver.get("https://www.demoblaze.com/");
			test.log(Status.PASS, "Navigated to Demoblaze website successfully.");
			test.log(Status.INFO,driver.getCurrentUrl());
			Thread.sleep(1000);

			driver.findElement(By.id("login2")).click();
			test.log(Status.PASS, "Login button clicked successfully.");
			Thread.sleep(1000);

			String path1 =CaptureScreenshot("Step1_LoginPage");
			test.log(Status.INFO, "Screen captured for Demoblaze login page-Step1.");
			test.addScreenCaptureFromPath(path1);

			driver.findElement(By.id("loginusername")).sendKeys("Rekha3211");
			test.log(Status.PASS, " Valid UserId entered successfully. ");
			Thread.sleep(1800);
			driver.findElement(By.id("loginpassword")).sendKeys("");
			test.log(Status.PASS, "Valid Password entered successfully. ");
			Thread.sleep(2000);

			String path2 =CaptureScreenshot("Step2_BeforeLoginPage");
			test.log(Status.INFO, "Screen captured for Demoblaze LoginPage before Login-step 2.");
			test.addScreenCaptureFromPath(path2);
			Thread.sleep(1500);

			driver.findElement(By.xpath("//button[starts-with(@onclick,'logIn()')]")).click();
			test.log(Status.PASS, "Login button clicked Successfully.");
			Thread.sleep(2100);

			al=driver.switchTo().alert();
			test.log(Status.INFO,"Login with valid date-Alert: "+al.getText());


		} catch (Exception e) {

			test.fail("Test encountered an exception: " + e.getMessage());

		} finally {

			if (driver != null) {
				driver.quit();
				test.log(Status.INFO, "Browser closed successfully.");
			}

			test=extent.createTest("Demoblaze_InvalidLogin", 
					"Validating the title of Demoblaze homepage Using Invalid Date");
			String Nname ="chrome";
			LaunchBrowser(Nname);
			try {
				test.log(Status.INFO, bName+" Browser Launched successfully.");
				driver.manage().window().maximize();
				driver.get("https://www.demoblaze.com/");
				test.log(Status.PASS, "Navigated to Demoblaze website successfully.");
				test.log(Status.INFO,driver.getCurrentUrl());
				Thread.sleep(1000);

				driver.findElement(By.id("login2")).click();
				test.log(Status.PASS, "Login button clicked successfully.");
				Thread.sleep(1000);

				String path1 =CaptureScreenshot("Step1_LoginPage");
				test.log(Status.INFO, "Screen captured for Demoblaze login page-Step1.");
				test.addScreenCaptureFromPath(path1);

				driver.findElement(By.id("loginusername")).sendKeys("UserId12+3");
				test.log(Status.FAIL, " Invalid UserId 'UserId12+3' entered successfully. ");
				Thread.sleep(1800);
				driver.findElement(By.id("loginpassword")).sendKeys("21/10/26");
				test.log(Status.FAIL, "Invalid Password '21/10/26' entered successfully. ");
				Thread.sleep(2000);

				String path2=CaptureScreenshot("Step2_LoginPage");
				test.log(Status.INFO, "Screen captured for Demoblaze Login page before InvalidLogin_step2.");
				test.addScreenCaptureFromPath(path2);
				Thread.sleep(1500);

				driver.findElement(By.xpath("//button[starts-with(@onclick,'logIn()')]")).click();
				//Thread.sleep(1000);
				test.log(Status.PASS, "Login button clicked Successfully.");
				Thread.sleep(2100);

				al=driver.switchTo().alert();
				test.log(Status.INFO,"Login failed with invalid date-Alert: "+al.getText());
				/*String path5=CaptureScreenshot("Step5_AfterAlert");
				test.log(Status.PASS, "Screen captured for Demoblaze AfterAlert-Step5");
				test.addScreenCaptureFromPath(path5);*/

			} catch (Exception e) {

				test.fail("Test encountered an exception: " + e.getMessage());

			} finally {

				if (driver != null) {
					driver.quit();
					test.log(Status.INFO, "Browser closed successfully.");
				}


				extent.flush();
				System.out.println("Execution complete. \nReport generated at: " + reportPath);
			} 
		}
	}
	public static void main(String[] args) {
		DemoblazeSOpen o=new DemoblazeSOpen();
		o.DemoblazeLogin();
	}
}