package ProjectTask;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;



public class DemoblazeAddToCart {    
	WebDriver driver;
	ExtentTest test;       // global
	ExtentReports extent;  // global
	String reportPath;
	Alert al;

	@BeforeSuite
	public void reportSetup() {
		reportPath = System.getProperty("user.dir") + "/Reports/Demoblaze_Report.html";
		ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);

		extent = new ExtentReports();  
		extent.attachReporter(spark);

		spark.config().setReportName("Demoblaze Automation Report");
		spark.config().setDocumentTitle("Demoblaze Add to Cart Testing");
		extent.setSystemInfo("Tester", "You");
		extent.setSystemInfo("Site", "Demoblaze.com");
	}

	@BeforeMethod
	public void setup() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.demoblaze.com/");
	}

	@Test(priority = 1)
	public void AddToCart_Laptop() {
		test = extent.createTest("Add MacBook to Cart");  // "ExtentTest" data type kadhla

		try {
			test.log(Status.INFO, "Click on Laptops menu");
			driver.findElement(By.linkText("Laptops")).click();
			Thread.sleep(2000);

			test.log(Status.INFO, "Select MacBook air");
			driver.findElement(By.linkText("MacBook air")).click();
			Thread.sleep(2000);

			test.log(Status.INFO, "Click Add to Cart button");
			driver.findElement(By.linkText("Add to cart")).click();
			Thread.sleep(2000);
			
			

			al = driver.switchTo().alert();
			String alertMsg = al.getText();
			test.log(Status.INFO, "Alert Message: " + alertMsg);

			if(alertMsg.contains("Product added")) {
				test.pass("Product added to cart successfully");
			} else {
				test.fail("Product not added");
			}
			al.accept();

		} catch(Exception e) {
			test.fail("Test Failed: " + e.getMessage());
		}
	}

	@Test(priority = 2)
	public void VerifyCart() {
		test = extent.createTest("Verify Product in Cart");

		try {
			test.log(Status.INFO, "Click on Cart button");
			driver.findElement(By.id("cartur")).click();
			Thread.sleep(2000);

			boolean productPresent = driver.findElement(By.xpath("//td[text()='MacBook air']")).isDisplayed();

			if(productPresent) {
				test.pass("MacBook air is present in Cart");
			} else {
				test.fail("Product not found in Cart");
			}

		} catch(Exception e) {
			test.fail("Test Failed: " + e.getMessage());
		}
	}

	@AfterMethod
	public void tearDown() {
		test.log(Status.INFO, "Browser closed successfully");
		if(driver != null) {
			driver.quit();
		}
	}

	@AfterSuite
	public void flushReport() {
		extent.flush();
		System.out.println("Report generated: " + reportPath);
	}
}



