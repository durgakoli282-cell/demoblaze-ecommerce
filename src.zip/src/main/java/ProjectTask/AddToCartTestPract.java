package ProjectTask;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import junit.framework.Assert;

public class AddToCartTestPract extends BaseTest {

	String reportPath =System.getProperty("user.dir") +"/Reports/ExtentReport"+timeStamp+".html";
	ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
	ExtentReports extent = new ExtentReports();
	Alert al;
	@Test
	public void AddToCard() {
		extent.attachReporter(spark);
		spark.config().setReportName("Demoblaze Automation Project");
		spark.config().setDocumentTitle("Demoblaze Add to Card ");
		extent.setSystemInfo("Demoblaze E-Commerce Website Automation.", "Demoblaze Automation Framework.");
		ExtentTest test = extent.createTest("Demoblaze_AddToCardTest", 
				"Validate that user is able to add samsung Galaxy S6 to cart and get 'Product addded' alert");
	   String bName="chrome";
	   LaunchBrowser(bName);
	   try
	   {
		   test.log(Status.INFO, bName +" Browser Launched Successfully.");
		   driver.manage().window().maximize();
		   driver.get("https://www.demoblaze.com/");
		   test.log(Status.INFO, "Navigated to Demoblaze website successfully.");
		   Thread.sleep(5000);
		   
		   driver.findElement(By.linkText("Samsung galaxy s6")).click();
		   test.log(Status.PASS, "Clicked on Product Link Successfully.");
		   Thread.sleep(5000);
		   
		   driver.findElement(By.linkText("Add to cart")).click();
		   test.log(Status.PASS, "Add to card clicked Successfully.");
		   Thread.sleep(5000);
		   
		   al=driver.switchTo().alert();
		   test.log(Status.PASS," Verified Alert message:"+al.getText());
		  // Thread.sleep(5000);
		   al.accept();
		   
	   }
	  catch(Exception e) {
			test.fail("Test encountered an exception: " + e.getMessage());
		}
		finally {

			if (driver != null) {
				driver.quit();
				test.log(Status.INFO, "Browser closed successfully.");
			}
			extent.flush();
			System.out.println("Execution complete. \nReport generated at: " + reportPath);
		
		
	  }
		}
	public static void main(String[] args) {
		AddToCartTestPract o=new AddToCartTestPract();
		o.AddToCard();
	}
}
