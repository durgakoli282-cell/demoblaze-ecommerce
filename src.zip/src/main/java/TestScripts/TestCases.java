package TestScripts;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class TestCases extends Repository {
	// 1. Initialize Extent Reports and Spark Reporter
    String reportPath = System.getProperty("user.dir") +"/Reports/ExtentReport"+timeStamp+".html";
    ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
    ExtentReports extent = new ExtentReports();

	@Test
	 public void setupReport() {
		 extent.attachReporter(spark);
		// 2. Create a test entry in the report
	        ExtentTest test = extent.createTest("Google Title Verification", 
	        		"Validating the title of Google homepage without TestNG");
	        String bName="CHROME";
	       BrowserSetting(bName);
	        try {
	            test.log(Status.INFO, bName+" Browser launched successfully.");
	            driver.manage().window().maximize();
	            driver.get("https://google.co.in");
	            test.log(Status.PASS, "Navigated to Google website.");
	            CaptureScreen("NavGoogle");
	            // 4. Perform validation and log results
	            String actualTitle = driver.getTitle();
	            if (actualTitle.equals("Googlee")) {
	                test.pass("Title verification passed. Actual title: " 
	            + actualTitle);
	            } else {
	                test.fail("Title verification failed. "
	                		+ "Expected 'Google' but got: " + actualTitle);
	            }

	        } catch (Exception e) {
	            // Log any unexpected exceptions directly to the report
	            test.fail("Test encountered an exception: " + e.getMessage());
	            
	        } finally {
	            // 5. Clean up and close the browser
	            if (driver != null) {
	            	driver.quit();
	                test.log(Status.INFO, "Browser closed successfully.");
	            }

	            // 6. Mandatory: Write all data to the report file
	            extent.flush();
	            System.out.println("Execution complete. \nReport generated at: " + reportPath);
	        }    
	 }
	 /*public static void main(String[]args) {
			TestCases t=new TestCases();
			t.setupReport();
		}*/


}
