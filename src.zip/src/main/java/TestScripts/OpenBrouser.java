package TestScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Test;

public class OpenBrouser {
	WebDriver driver;

	public void setup() {
		driver = new ChromeDriver();
		//driver = new EdgeDriver();
		driver.get("https://www.amazon.com"); 
		driver.manage().window().maximize();
	}
public static void main(String[] args) {
	OpenBrouser o=new OpenBrouser();
	o.setup();
}

	
}


