package TestScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BrowserLaunched {

	WebDriver driver;
	@BeforeMethod
	public void BrowserSetting() {
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Test	
		public void Rediif() {
		driver.get("https://www.rediff.com/");
		}
		
	
}
