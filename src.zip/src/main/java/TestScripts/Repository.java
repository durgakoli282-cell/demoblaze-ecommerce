package TestScripts;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;


public class Repository {
public WebDriver driver;
	
	public String timeStamp = new 	SimpleDateFormat
			("yyyyddMM_HHmmss").format(new Date());
	
	public void BrowserSetting(String sBrowser) {
		if(sBrowser.equalsIgnoreCase("Chrome")){
			driver=new ChromeDriver();
		}
		else if (sBrowser.equalsIgnoreCase("Edge")){
			driver=new EdgeDriver();
		}
		else {
			System.out.println("Invalid Value");
		}
	}
    
	public void CaptureScreen(String ScrName){
		try
		{
			Thread.sleep(1100);
			
			File source= ((TakesScreenshot)driver).
					getScreenshotAs(OutputType.FILE);
			File dest = new File("G:\\Automation\\Screenshort"+timeStamp+".png");
			FileHandler.copy(source, dest);
			System.out.println("Image Capturde.");

		} 
		catch (IOException e)
		{ 
			//e.printStackTrace();
			System.out.println("Invalid Path or file");
		}
		//driver.close();
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}



