package DemoblazeProject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseClass {

	public WebDriver driver;
	@BeforeClass
	public void SetupBrowser() {

		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.demoblaze.com/");
		
	}
	public String CaptureScreenshot(String Screenshort) throws IOException, InterruptedException {
		Thread.sleep(1000);
		String timeStamp = new 	SimpleDateFormat
				("yyyyddMM_HHmmss").format(new Date());
		
		File Source =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String path ="G:\\Automation\\Screenshort\\DemoblazeScreenCap_"+Screenshort+"_"+timeStamp+".png";
		File dest=new File(path);
	    FileHandler.copy(Source, dest);
	    System.out.println("Screenshort Saved:"+path);
	
	    return path;
	}
	
	@AfterClass
	public void TearDown() {
		driver.quit();
	}
	
	
}
