package DemoblazeProject;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

	
	private static ExtentReports extent;
	public static void ExtentReports () {
	
	 String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	
	String reportPath = System.getProperty("user.dir") +"/Reports/ExtentReport"+timeStamp+".html";
	
	ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
	spark.config().setReportName("Demoblaze Automation Project Report.");
    spark.config().setDocumentTitle("Demoblaze E-Commerce Website Automation.");
    
    extent =new ExtentReports();
    extent.attachReporter(spark);

    extent.setSystemInfo("Demoblaze E-Commerce Website Automation.", "Demoblaze Automation Framework.");
	ExtentTest test = extent.createTest("Demoblaze_ValidLogin", 
			"Validating the title of Demoblaze homepage with TestNG");
	  
	ExtentReports extent = new ExtentReports();
	
}

	
}
